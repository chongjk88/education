import productSagas from './product/sagas';
import cartSagas from './cart/sagas';

export default [
  productSagas,
  cartSagas,
];
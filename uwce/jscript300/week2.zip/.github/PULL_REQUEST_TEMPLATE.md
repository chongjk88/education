# Week 1 HW Submission

Please fill out the information below in order to complete your assignment. Feel free to update this comment later if necessary.

* Comfort rating on this assignment (1-5):
* Completion rating on this assignment (complete/incomplete):
* Github handles of code I've reviewed:

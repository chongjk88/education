const Timer = require('./Timer');

const countdown = new Timer(10);
countdown.start();
